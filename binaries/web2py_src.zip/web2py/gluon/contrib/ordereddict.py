# -*- coding: utf-8 -*-
"""
Dummy ordereddict module for backwards compatibility with applications that import OrderedDict from gluon.contrib.ordereddict

TODO: Remove this.
"""
from collections import OrderedDict
