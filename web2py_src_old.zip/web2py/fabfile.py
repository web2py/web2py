from fabric.api import run


def make_web2py():
    run('sudo ./make_web2py.py')


def deploy():
    run('sudo ./make_web2py.py deploy')
    run('sudo reboot now')
